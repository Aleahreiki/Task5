import requests
import time

BASE_URL = "http://127.0.0.1:8000"

def test_service():
    print("Testing /health endpoint...")
    res = requests.get(f"{BASE_URL}/health")
    print(res.status_code, res.json())
    
    print("\nTesting /predict endpoint with sample features...")
    payload = {"features": [0.4, 1.5, -0.2, 3.3]}
    res = requests.post(f"{BASE_URL}/predict", json=payload)
    print(res.status_code, res.json())

    print("\nSimulating multiple prediction requests to generate metrics...")
    for i in range(5):
        requests.post(f"{BASE_URL}/predict", json={"features": [float(i), 1.0, -1.0]})
        time.sleep(0.1)

    print("\nChecking /metrics endpoint...")
    res = requests.get(f"{BASE_URL}/metrics")
    print(res.status_code, res.json())

if __name__ == "__main__":
    try:
        test_service()
    except requests.exceptions.ConnectionError:
        print("Error: Could not connect to the API. Make sure FastAPI is running (uvicorn app:app --reload).")