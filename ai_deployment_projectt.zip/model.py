import time
import random

class DummyPredictor:
    """Simulates a pre-trained machine learning model (e.g., Tabular Fraud/Risk Classifier)."""
    def __init__(self):
        self.model_name = "AIModel-Production-v1.2"
        self.version = "1.2.0"
    
    def predict(self, features: list) -> dict:
        # Simulate slight inference latency
        time.sleep(0.02)
        
        # Dummy inference calculation
        score = float(sum(features) / len(features) if features else 0.5)
        prediction = 1 if score > 0.5 else 0
        confidence = round(random.uniform(0.78, 0.99), 4)
        
        return {
            "prediction": prediction,
            "probability": confidence,
            "model_version": self.version
        }