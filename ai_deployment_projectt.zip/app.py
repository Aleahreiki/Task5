import time
import logging
from fastapi import FastAPI, Request, HTTPException, status
from pydantic import BaseModel, Field
from model import DummyPredictor

# Configure structured logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger("ai_service")

app = FastAPI(
    title="AI Model Serving & Monitoring API",
    description="Proof-of-concept deployment of a containerized AI model with built-in telemetry and logging.",
    version="1.2.0"
)

predictor = DummyPredictor()

# In-memory metrics tracking for monitoring dashboard simulation
metrics_store = {
    "total_requests": 0,
    "successful_predictions": 0,
    "error_count": 0,
    "latency_history": []
}

class PredictionRequest(BaseModel):
    features: list[float] = Field(..., example=[0.5, 1.2, -0.3, 2.1])

@app.middleware("http")
async def log_requests(request: Request, call_next):
    start_time = time.time()
    metrics_store["total_requests"] += 1
    
    response = await call_next(request)
    
    duration = time.time() - start_time
    metrics_store["latency_history"].append(duration)
    
    # Keep only the last 1000 latency measurements in memory
    if len(metrics_store["latency_history"]) > 1000:
        metrics_store["latency_history"].pop(0)
        
    logger.info(
        f"Path: {request.url.path} | Method: {request.method} | "
        f"Status: {response.status_code} | Latency: {duration:.4f}s"
    )
    return response

@app.get("/health", status_code=status.HTTP_200_OK)
def health_check():
    """Liveness and readiness probe for container orchestration."""
    return {
        "status": "healthy",
        "model_loaded": True,
        "model_version": predictor.version
    }

@app.post("/predict")
def predict(payload: PredictionRequest):
    """Accepts feature data, runs model inference, and returns predictions."""
    try:
        if not payload.features:
            metrics_store["error_count"] += 1
            raise HTTPException(status_code=400, detail="Feature list cannot be empty.")
        
        result = predictor.predict(payload.features)
        metrics_store["successful_predictions"] += 1
        return {"status": "success", "data": result}
        
    except HTTPException as he:
        raise he
    except Exception as e:
        metrics_store["error_count"] += 1
        logger.error(f"Inference error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/metrics")
def get_metrics():
    """Exposes usage statistics, error rates, and average latency for monitoring."""
    total = metrics_store["total_requests"]
    avg_latency = (
        sum(metrics_store["latency_history"]) / len(metrics_store["latency_history"])
        if metrics_store["latency_history"] else 0
    )
    return {
        "total_requests": total,
        "successful_predictions": metrics_store["successful_predictions"],
        "error_count": metrics_store["error_count"],
        "error_rate": round(metrics_store["error_count"] / total, 4) if total > 0 else 0,
        "average_latency_seconds": round(avg_latency, 4)
    }